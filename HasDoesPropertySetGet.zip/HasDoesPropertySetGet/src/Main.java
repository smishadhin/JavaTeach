public class Main {
    public static void main(String[] args) {


        Rayyan ray = new Rayyan();

        ray.setHands(2);

        ray.handMovingToXYZ();

        ray.setHands(4);

        ray.handMovingToXYZ();


    }
}