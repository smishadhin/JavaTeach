public class Rayyan {

    // has property
    int hands;
    boolean isHandFunctional;
    boolean isHand;
    int eyes;
    boolean isEyesFunctional;
    boolean isEyes;
    int head;
    boolean isHeadFunctional;
    boolean isHead;
    int legs;
    boolean isLegFunctional;
    boolean isLeg;
    int body;
    boolean isBodyFunctional;
    boolean isBody;
    int arms;
    boolean isArmsFunctional;
    boolean isArms;
    int nose;
    boolean isNoseFunctional;
    boolean isNose;


    public int getHands() {
        return this.hands;
    }

    public void setHands(int hands) {
        this.hands = hands;
    }

    // does property
    public void handMovingToXYZ() {
        System.out.println(getHands());
    }

    void rayyanCanWork() {
    // call and print every getter

    }

}
