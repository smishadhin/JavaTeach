import java.util.Scanner;

public class Rent extends Utility {
    protected double HouseRent = 1495.50;

    public void RentFixed(){

        System.out.println("Rent::" + HouseRent);

    }
}

