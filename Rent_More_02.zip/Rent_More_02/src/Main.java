public class Main extends Rent {
    public static void main(String[] args) {

        Cash cash = new Cash();
        cash.Cash_Pickup();

    }

}